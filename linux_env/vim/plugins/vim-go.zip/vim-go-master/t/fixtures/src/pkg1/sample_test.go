package pkg1

import "testing"

func TestSample(t *testing.T) {
	Sample()
}
