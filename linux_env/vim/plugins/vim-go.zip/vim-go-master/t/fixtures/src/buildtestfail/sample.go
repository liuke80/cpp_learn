// set gopath before
//go:generate go test --coverprofile=sample.out
package pkg

func Sample() int {
	return 1
}
