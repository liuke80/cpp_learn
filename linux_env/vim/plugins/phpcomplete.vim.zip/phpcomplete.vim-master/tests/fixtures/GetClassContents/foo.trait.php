<?php

trait FooTrait {
	public $prop = 'baz';
}
